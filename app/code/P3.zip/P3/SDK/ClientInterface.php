<?php


namespace P3\SDK;

/**
 * Interface ClientInterface
 */
interface ClientInterface
{
    public function post(array $request);
}