<?php

namespace Tech9logy\ExtendWarranty\Controller\Index;

class RemoveServices extends \Magento\Framework\App\Action\Action
{
	/**
	* say hello text
	*/
	public function execute()
	{
		return true;
	}
}
